if (navigator.onLine) {
  console.log("online");
} else {
  console.log("offline");
}
